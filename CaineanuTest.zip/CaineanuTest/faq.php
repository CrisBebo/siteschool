<?php

	include 'HEADER/header.php';

?>



<html>
<head>
	<meta charset="UTF-8">
	<title>Cristian Caineanu - Privacy</title>
</head>

<body>

<h2>FAQ</h2>

<h3>Da chi è stato creato questo sito?</h3>

Questo sito è stato sviluppato dallo staff della CCNetworks.
<br><br>

<h3>Qual è lo scopo del sito?</h3>

Lo scopo di questo sito è quello di essere un esempio di ciò che uno studente dell'ultimo anno di un Istituto Superiore di 
Indirizzo Informatico dovrebbe riuscire a realizzare a fine anno.
<br><br>

<h3>Quali tecnologie e linguaggi si sono utilizzati per la creazione del sito?</h3>

Questo sito è stato sviluppato mediante linguaggi quali HTML, PHP, MYSQL, JAVASCRIPT, CSS e tecnologie BOOTSTRAP e GOOGLE APIS.
<br><br>


</body>

</html>



<?php

  include 'FOOTER/footer.php';

?>