<?php
   $db=new mysqli("192.168.1.14","root","root","phptutorial"); //metti i dati corretti
      if(!$db){
        die("Errore selezione database");
      }
?>
