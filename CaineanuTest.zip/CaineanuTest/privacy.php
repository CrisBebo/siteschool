<?php

	include 'HEADER/header.php';

?>



<html>
<head>
	<meta charset="UTF-8">
	<title>Cristian Caineanu - Privacy</title>
</head>

<body>

<h2>Privacy</h2>

<h3>Trattamento dei dati personali e Privacy</h3>
<br><br>

La presente Privacy Policy ha lo scopo di descrivere le modalità di gestione dei siti Internet, di secondo e terzo livello, 
di proprietà di CCNetworks, in riferimento al trattamento dei dati personali degli utenti/visitatori che li consultano. 
<br><br>

CCNetworks tratta tutti i dati personali degli utenti/visitatori dei servizi offerti, nel pieno rispetto di quanto previsto dalla normativa 
nazionale italiana in materia di privacy e, in particolare del D. Lgs. 196/2003. Ove l’accesso a particolari servizi venga subordinato alla 
registrazione previa comunicazione di dati personali, viene fornita un’informativa specifica al momento della sottoscrizione dei servizi stessi.
<br><br>

L’acquisizione dei dati, che possono essere richiesti, è il presupposto indispensabile per accedere ai servizi offerti sui siti della 
CCNetworks conserva i dati tecnici relativi alle connessioni (log) per consentire i controlli di sicurezza richiesti dalla Legge e al fine 
di migliorare laqualità dei servizi offerti e personalizzarli in relazione alle esigenze degli utenti/visitatori.
<br><br>

I dati inseriti possono essere utilizzati da CCNetworks anche al fine di inviare periodicamente messaggi di posta elettronica contenenti 
pubblicità, materiale promozionale, iniziative promozionali, comunicazioni commerciali.
<br><br>

I dati personali, raccolti e conservati in banche dati della CCNetworks, sono trattati da dipendenti e/o collaboratori del titolare del 
trattamento in qualità di incaricati. Non sono oggetto di diffusione o comunicazione a Terzi, se non nei casi previsti dalla informativa e/o 
dalla Legge e, comunque, con le modalità da questa consentite.
<br><br>

Sui siti web di CCNetworks, sono utilizzati dei marcatori temporanei (cookie). Per cookie si intende il dato informativo, attivo per la 
durata della connessione, che viene trasmesso da CCNetworks al computer dell’utente al fine di permettere una rapida identificazione. 
L’utente può disattivare i cookie modificando le ipostazioni del browser. Si avverte che tale disattivazione potrà rallentare o impedire 
l’accesso a tutto o parte del sito.
<br><br>

CCNetworks provvede, in conformità con le vigenti disposizioni di legge in materia, alla registrazione dei file di log. Tali dati non 
consentono un’identificazione dell’utente se non in seguito ad una serie di operazioni di elaborazione e interconnessione, e necessariamente 
attraverso dati forniti da altri provider. Operazioni che potranno essere effettuate esclusivamente su richiesta delle competenti Autorità 
Giudiziarie, a ciò autorizzate da espresse disposizioni di legge atte a prevenire e/o reprimere i reati.
<br><br>

Google, in qualità di rivenditore e concessionario di pubblicità, utilizza il sistema dei cookies per servire pubblicità su questo sito. Il 
sistema di cookie DART utilizzato da Google consente di far apparire pubblicità basate sulle visite a questo ed ad altri siti.
Gli utilizzatori possono rinunciare all’uso del sistema di cookie DART andando sulla pagina Google ad and content network privacy policy.
<br><br>

CCNetworks utilizza il servizo Google Analytics per generare statistiche di accesso alle pagine del sito, per analisi di traffico interno. 
I dati forniti da Google Analytics non permettono in alcun modo di identificare il singolo utente che interagisce sulle pagine del sito, ma 
riporta informazioni aggregate su quali siano le dinamiche di navigazione all’interno del sito, il numero di utenti unici e di pagine 
visualizzate.
<br><br>

CCNetworks può inserire all’interno delle proprie pagine campagne pubblicitarie gestite da aziende terze, le quali facciano utilizzo per 
l’erogazione di questi servizi di propri cookie non gestiti da CCNetworks in alcun modo. L’utente può scegliere di bloccare questi cookie 
intervenendo sulle impostazioni del proprio browser; si ricorda come anche in questo caso tale disattivazione potrà rallentare o impedire 
l’accesso a tutto o parte del sito.
<br><br>

CCNetworks utilizza servizi di statistiche esterni alla struttura. I servizi di statistiche utilizzano cookie per elaborare i propri dati. 
L’utente può disattivare i cookie modificando le impostazioni del browser. Si avverte che tale disattivazione potrà rallentare o impedire 
l’accesso a tutto o parte del sito.
<br><br>

L’invio da parte degli utenti/visitatori di propri dati personali per accedere a determinati servizi, ovvero per effettuare richieste in posta 
elettronica, comporta l’acquisizione da parte di CCNetworks dell’indirizzo del mittente e/o di altri eventuali dati personali. Tali dati 
verranno trattati esclusivamente per rispondere alla richiesta, ovvero per la fornitura del servizio, e verranno comunicati a terzi solo nel 
caso in cui sia necessario per ottemperare alle richieste degli utenti/visitatori stessi.
<br><br>

Il trattamento viene effettuato attraverso strumenti automatizzati per il tempo strettamente necessario a conseguire gli scopi per i quali i 
dati sono stati raccolti e, comunque, in conformità alle disposizioni normative vigenti in materia.
Specifiche misure di sicurezza sono osservate per prevenire la perdita dei dati, usi illeciti o non corretti ed accessi non autorizzati.
<br><br>

CCNetworks non può farsi carico della responsabilità di qualsiasi accesso non autorizzato né dello smarrimento delle informazioni 
personali al di fuori del proprio controllo.
<br><br>

Il titolare del trattamento dei dati è CCNetworks, sede legale VIA SAN MARCO 18/3 , 36056 TEZZE SUL BRENTA (VI), che potrà utilizzarli per 
tutte le finalità individuate nell’informativa specifica fornita in occasione della sottoscrizione dei vari servizi.
<br><br>

Gli utenti/visitatori hanno facoltà di esercitare i diritti previsti dall’art. 7 del D. Lgs. 196/03. In ogni momento, inoltre, esercitando il 
diritto di recesso da tutti i servizi sottoscritti, è possibile chiedere la cancellazione totale dei dati forniti.
<br><br>
<br><br>

Art. 7. Diritto di accesso ai dati personali ed altri diritti
<br><br>

1. L’interessato ha diritto di ottenere la conferma dell’esistenza o meno di dati personali che lo riguardano, anche se non ancora registrati, 
e la loro comunicazione in forma intelligibile.
<br><br><br>

2. L’interessato ha diritto di ottenere l’indicazione:
<br><br>

a) dell’origine dei dati personali;
<br>
b) delle finalità e modalità del trattamento;
<br>
c) della logica applicata in caso di trattamento effettuato con l’ausilio di strumenti elettronici;
<br>
d) degli estremi identificativi del titolare, dei responsabili e del rappresentante designato ai sensi dell’articolo 5, comma 2;
<br>
e) dei soggetti o delle categorie di soggetti ai quali i dati personali possono essere comunicati o che possono venirne a conoscenza in qualità 
di rappresentante designato nel territorio dello Stato, di responsabili o incaricati.
<br><br><br>

3. L’interessato ha diritto di ottenere:
<br><br>

a) l’aggiornamento, la rettificazione ovvero, quando vi ha interesse, l’integrazione dei dati;
<br>
b) la cancellazione, la trasformazione in forma anonima o il blocco dei dati trattati in violazione di legge, compresi quelli di cui non è 
necessaria la conservazione in relazione agli scopi per i quali i dati sono stati raccolti o successivamente trattati;
<br>
c) l’attestazione che le operazioni di cui alle lettere a) e b) sono state portate a conoscenza, anche per quanto riguarda il loro contenuto, 
di coloro ai quali i dati sono stati comunicati o diffusi, eccettuato il caso in cui tale adempimento si rivela impossibile o comporta un 
impiego di mezzi manifestamente sproporzionato rispetto al diritto tutelato.
<br><br><br>

4. L’interessato ha diritto di opporsi, in tutto o in parte:
<br><br>

a) per motivi legittimi al trattamento dei dati personali che lo riguardano, ancorché pertinenti allo scopo della raccolta;
<br>
b) al trattamento di dati personali che lo riguardano a fini di invio di materiale pubblicitario o di vendita diretta o per il compimento di 
ricerche di mercato o di comunicazione commerciale.
<br><br>

</body>

</html>



<?php

  include 'FOOTER/footer.php';

?>