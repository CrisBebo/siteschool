<?php

	include 'HEADER/header.php';

?>



<html>
<head>
	<meta charset="UTF-8">
	<title>Cristian Caineanu - Utilizzo dei Cookie</title>
</head>
<body>



<h2>Informativa sui cookie</h2>

<h3>Titolare del trattamento</h3>

Il titolare del trattamento dei dati è CCNetworks, con sede legale VIA SAN MARCO 18/3, 36056 TEZZE SUL BRENTA (VI).
<br><br>

Utilizzando questo sito, cliccando su un elemento qualsiasi, chiudendo il banner visualizzato all'apertura delle pagine, facendo uno scroll, 
acconsenti all'utilizzo dei cookie.
<br><br><br><br>


<h3>Cosa sono i Cookie</h3>

Si tratta di piccoli file di testo memorizzati nel browser dell'utente per periodi di tempo variabili, a partire da poche ore fino ad un massimo 
di un anno.
<br><br>

I cookie sono utili perché consentono a un sito web di riconoscere il dispositivo dell'utente, ricordare le preferenze, dati di login, le azioni 
compiute e in generale contribuiscono a migliorare la sicurezza e l'esperienza di navigazione.
<br><br>

Si usano anche per far visualizzare contenuti pubblicitari più pertinenti ai propri interessi (i c.d. cookie di profilazione).
<br><br><br><br>


<h3>Come si sliminano i cookie</h3>

E' possibile disattivare tutti i cookie, sia di questo sito che di terze parti, modificando le impostazioni del proprio browser.
<br><br><br><br>


<h3>I cookie che utilizziamo</h3>

I cookie utilizzati sono indispensabili per il corretto funzionamento del sito. Senza non sarebbero possibili operazioni comuni come un 
login oppure inviare un modulo di contatto.
<br><br>

A questa categoria appartengono anche i cookie analitici che ci aiutano a conoscere dati come il numero di utenti che visitano questo sito, 
i contenuti più popolari, i meno popolari oppure il tempo speso su ogni contenuto.
<br><br>

Tutte le informazioni raccolte da questi cookie sono anonime e non collegate ai dati personali dell'utente. I servizi di terze parti che 
utilizziamo per questa finalità (Google analytics e Shinystat) rendono anonimi e non riconducibili a singoli individui questi dati.
<br><br>

I cookie utilizzati in questo sito possono comunque essere limitati o eliminati agendo sulle impostazioni del proprio browser. 
<br><br>


</body>

</html>



<?php

  include 'FOOTER/footer.php';

?>