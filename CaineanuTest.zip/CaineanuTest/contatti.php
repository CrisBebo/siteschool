<?php
  
  include 'HEADER/header.php';

?>



<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">



<!-- ----------------------- -->
<style>
html {
  box-sizing: border-box;
}

*, *:before, *:after {
  box-sizing: inherit;
}

.column {
  float: left;
  width: 50%;
  margin-bottom: 16px;
  padding: 0 8px;
}

@media (max-width: 650px) {
  .column {
    width: 100%;
    display: block;
  }
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
}

.container {
  padding: 0 16px;
}

.container::after, .row::after {
  content: "";
  clear: both;
  display: table;
}

.title {
  color: grey;
}

.button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
}

.button:hover {
  background-color: #555;
}
</style>
<!-- ----------------------- -->
<!-- ----------------------- -->
<style>
body, html {
    height: 100%;
}

/* The hero image */
.hero-image {
    /* The image used */
    background-image: url("IMG/contacts/contacts.jpg");

    /* Set a specific height */
    height: 50%;

    /* Position and center the image to scale nicely on all screens */
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    position: relative;
}

/* Place text in the middle of the image */
.hero-text {
    text-align: center;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    color: white;
}
</style>
<!-- ----------------------- -->

</head>



<body>

<div class="hero-image">
  <div class="hero-text">
    <h1 style="font-size: 50px">Contatti</h1>
  </div>
</div> 

<br>

<div class="row">
  <div class="column">
    <div class="card">
      <img src="IMG/contacts/bebo.png" alt="Bebo" style="width:100%">
      <div class="container">
        <h2>Cristian Caineanu</h2>
        <p class="title">CEO, Founder & Art Director</p>
        <p>Solare e sempre pronto a dare una mano, il mio focus in ogni lavoro che faccio è incentrato sul aspetto estetico e sulla funzionalità.</p>
        <p>cris.bebo.cb@gmail.com</p>
        <p><button class="button">Contact</button></p>
      </div>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="IMG/contacts/farinz.png" alt="Farinz" style="width:100%">
      <div class="container">
        <h2>Luca Farina</h2>
        <p class="title">Developer</p>
        <p>Sempre disposto a fare festa con gli amici, ma anche in ambito lavorativo mi do da fare per svolgere le mansioni assegnate.</p>
        <p>farina.luca987@gmail.com</p>
        <p><button class="button">Contact</button></p>
      </div>
    </div>
  </div>
</div>

</body>
</html>



<?php
  
  include 'FOOTER/footer.php';

?>