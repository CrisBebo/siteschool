<?php

  include 'HEADER/header.php';

?>



<html>
<head>
<meta charset="UTF-8">
<title>Cristian Caineanu</title>
</head>



<!------------------------------------------------------------------------------------ IMG GRID ----------------------------------------------------------------------------------- -->
<style type="text/css">
.row {
  display: flex;
  flex-wrap: wrap;
  padding: 0 4px;
  margin: auto;
}

/* Create four equal columns that sits next to each other */
.column {
  flex: 80%;
  max-width: 50%;
  padding: 0px;
}

.column img {
  max-width:98%;
  max-height:100%;
  margin-top: 2%;
  vertical-align: middle;
}

/* Responsive layout - makes a two column-layout instead of four columns */
@media (max-width: 800px) {
  .column {
    flex: 50%;
    max-width: 50%;
  }
}

/* Responsive layout - makes the two columns stack on top of each other instead of next to each other */
@media (max-width: 600px) {
  .column {
    flex: 100%;
    max-width: 100%;
  }
}
</style>
<!----------------------------------------------------------------------------------- IMG GRID END -------------------------------------------------------------------------------- -->

<!----------------------------------------------------------------------------------- FADE IN OVER -------------------------------------------------------------------------------- -->
<style>
.container {
  position: relative;
  width: 100%;
}

.image {
  display: block;
  width: 100%;
  height: auto;
}

/* NUMBER 1 = LIGHT BLUE */
.overlay1 {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  height: 100%;
  width: 98%;
  opacity: 0;
  transition: .5s ease;
  background-color: #82d0ff;
}

.container:hover .overlay1 {
  opacity: 1;
}

/* NUMBER 2 = PINK */
.overlay2 {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  height: 100%;
  width: 98%;
  opacity: 0;
  transition: .5s ease;
  background-color: #ffafba;
}

.container:hover .overlay2 {
  opacity: 1;
}

/* NUMBER 3 = GREY */
.overlay3 {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  height: 100%;
  width: 98%;
  opacity: 0;
  transition: .5s ease;
  background-color: #707070;
}

.container:hover .overlay3 {
  opacity: 1;
}

.text {
  color: white;
  font-size: 20px;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  text-align: center;
  text-decoration: none;
}
</style>
<!------------------------------------------------------------------------------------- FADE END ---------------------------------------------------------------------------------- -->



<body background="IMG/wallpaper.png">


<div class="row">
  <div class="column">

    <div class="container">
      <img src="IMG/carousel/soccer.png" class="image">
      <div class="overlay1">
        <a href="calcio.php" class="text">Calcio</a>
      </div>
    </div>

    <div class="container">
      <img src="IMG/carousel/warehouse.png" class="image">
      <div class="overlay2">
        <a href="magazzino.php" class="text">Magazzino</a>
      </div>
    </div>

    <div class="container">
      <img src="IMG/carousel/calculator.png" class="image">
      <div class="overlay3">
        <a href="calcolatrice.php" class="text">Calcolatrice</a>
      </div>
    </div>

    <div class="container">
      <img src="IMG/carousel/soccer.png" class="image">
      <div class="overlay1">
         <a href="calcio.php" class="text">Calcio</a>
      </div>
    </div>

    <div class="container">
      <img src="IMG/carousel/calculator.png" class="image">
      <div class="overlay3">
        <a href="calcolatrice.php" class="text">Calcolatrice</a>
      </div>
    </div>

    <div class="container">
      <img src="IMG/carousel/warehouse.png" class="image">
      <div class="overlay2">
        <a href="magazzino.php" class="text">Magazzino</a>
      </div>
    </div>



  </div>
  <div class="column">



    <div class="container">
      <img src="IMG/carousel/calculator.png" class="image">
      <div class="overlay3">
        <a href="calcolatrice.php" class="text">Calcolatrice</a>
      </div>
    </div>

    <div class="container">
      <img src="IMG/carousel/soccer.png" class="image">
      <div class="overlay1">
         <a href="calcio.php" class="text">Calcio</a>
      </div>
    </div>

    <div class="container">
      <img src="IMG/carousel/warehouse.png" class="image">
      <div class="overlay2">
        <a href="magazzino.php" class="text">Magazzino</a>
      </div>
    </div>

    <div class="container">
      <img src="IMG/carousel/warehouse.png" class="image">
      <div class="overlay2">
        <a href="magazzino.php" class="text">Magazzino</a>
      </div>
    </div>

    <div class="container">
      <img src="IMG/carousel/soccer.png" class="image">
      <div class="overlay1">
         <a href="calcio.php" class="text">Calcio</a>
      </div>
    </div>

    <div class="container">
      <img src="IMG/carousel/calculator.png" class="image">
      <div class="overlay3">
        <a href="calcolatrice.php" class="text">Calcolatrice</a>
      </div>
    </div>

  </div>
</div>



</body>
</html>

<?php

  include 'FOOTER/footer.php';

?>