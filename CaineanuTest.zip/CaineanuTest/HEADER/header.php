<!DOCTYPE html>
<html>

<head>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Cristian Caineanu</title>

	<!--
	<link rel="stylesheet" href="assets/demo.css">
	-->

	<link rel="stylesheet" href="HEADER/assets/header.css">
	<link href='http://fonts.googleapis.com/css?family=Cookie' rel='stylesheet' type='text/css'>

</head>



<!------------------------------------------------------------------------------------ STICKY ----------------------------------------------------------------------------------- -->
<style type="text/css">
/* The sticky class is added to the header with JS when it reaches its scroll position */
.sticky {
  position: fixed;
  top: 0;
  width: 100%
}

/* Add some top padding to the page content to prevent sudden quick movement (as the header gets a new position at the top of the page (position:fixed and top:0) */
.sticky + .content {
  padding-top: 102px;
}
</style>



<script>
window.onscroll = function() {myFunction()};

var header = document.getElementById("myHeader");
var sticky = header.offsetTop;

function myFunction() {
  if (window.pageYOffset >= sticky) {
    header.classList.add("sticky");
  } else {
    header.classList.remove("sticky");
  }
}
</script>
<!---------------------------------------------------------------------------------- STICKY END --------------------------------------------------------------------------------- -->

<!----------------------------------------------------------------------------------- SIDENAV ----------------------------------------------------------------------------------- -->
<style>
body {
    font-family: "Lato", sans-serif;
}

.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    left: 0;
    background-color: #292c2f;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
    text-align:center;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;

}

.sidenav a:hover{
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
</style>



<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "100%";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>
<!---------------------------------------------------------------------------------- SIDENAV END --------------------------------------------------------------------------------- -->

<!----------------------------------------------------------------------------------- DIV STYLE ---------------------------------------------------------------------------------- -->
    <style>
    div.absolute {
        position: absolute;
        bottom: 15%;
        right: 0;
        width: 100%;
        text-align:center;
    }
    </style>
<!------------------------------------------------------------------------------------ DIV END ----------------------------------------------------------------------------------- -->

<!---------------------------------------------------------------------------------- LOGO STYLE ---------------------------------------------------------------------------------- -->
    <style>
    .logo{
        width: 5%; 
        height: 5%; 
        position: relative;
        vertical-align: middle;
        float: left;
    }
    
    @media (max-width: 600px) {
	.logo {
		width: 20%; 
        height: 20%;
        margin: auto;
        vertical-align: middle;
	}
}
    </style>
<!----------------------------------------------------------------------------------- LOGO END ----------------------------------------------------------------------------------- -->

<!---------------------------------------------------------------------------------- GO TO TOP BTN -------------------------------------------------------------------------------- -->
<style>

body {
  font-family: Arial, Helvetica, sans-serif;
  font-size: 20px;
}

#myBtn {
  display: none;
  position: fixed;
  bottom: 30px;
  right: 30px;
  z-index: 99;
  font-size: 20px;
  border: none;
  outline: none;
  background-color: grey;
  color: white;
  cursor: pointer;
  padding: 20px;
  border-radius: 30%;
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}

#myBtn:hover {
  background-color: #555;
}
</style>
<script>
// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.getElementById("myBtn").style.display = "block";
    } else {
        document.getElementById("myBtn").style.display = "none";
    }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}

// Smooth scrolling
function scrollToTop(scrollDuration) {
    var cosParameter = window.scrollY / 2, scrollCount = 0, oldTimestamp = performance.now();
    function step (newTimestamp) {
      scrollCount += Math.PI / (scrollDuration / (newTimestamp - oldTimestamp));
      if (scrollCount >= Math.PI) window.scrollTo(0, 0);
      if (window.scrollY === 0) return;
      window.scrollTo(0, Math.round(cosParameter + cosParameter * Math.cos(scrollCount)));
      oldTimestamp = newTimestamp;
      window.requestAnimationFrame(step);
    }
    window.requestAnimationFrame(step);
  }
</script>
<!---------------------------------------------------------------------------------- GO TO TOP END -------------------------------------------------------------------------------- -->



<body>

<header class="header-login-signup" id="myHeader">

	<div class="header-limiter">

		<a href="#" onclick="openNav()"><img src="IMG/logo/cclogo1.png" alt="logo" class="logo"></a> <!--add onclick="openNav()" if you activate the SIDENAV -->
	</div>



  <div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="index.php" style="color:#608bd2">Home</a>
  <a href="progetti.php">Progetti</a>
  <a href="contatti.php">Contatti</a>
  <a href="t-rex/index.php">Gioco T-Rex</a>

  <div class="absolute">
    <a href="#">Registrati</a></li>
    <a href="login.php">Accedi</a></li>
  </div>
</div>

</header>

<!--<button onclick="topFunction()" id="myBtn" title="Go to top">▲</button>-->
<button onclick="scrollToTop(1000);" id="myBtn" title="Go to top">▲</button>

</body>
</html>
